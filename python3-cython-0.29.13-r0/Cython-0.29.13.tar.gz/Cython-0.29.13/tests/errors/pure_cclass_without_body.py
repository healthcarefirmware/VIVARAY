# mode: error

class Test(object):
    pass

_ERRORS = u"""
3:5: C class 'Test' is declared but not defined
"""
