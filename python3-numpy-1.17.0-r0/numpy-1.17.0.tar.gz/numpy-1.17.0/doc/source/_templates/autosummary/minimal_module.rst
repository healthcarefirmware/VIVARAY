{{ fullname | escape | underline}}

.. automodule:: {{ fullname }}

   {% block docstring %}
   {% endblock %}


